JC Nutrition V9.10.2 · Menú variado
- Menú semanal variado manteniendo objetivos por tipo de día.
- Quark Milbona 20% incorporado con valores reales: 97 kcal, P 10.3, HC 3.7, G 4.3 / 100 g.
- Navegación visual unificada con JC Training.
- Enlace Training integrado en la barra inferior.
- Consumido/objetivo y sustituciones contextuales conservados.

- V9.10.1: Quark Milbona 20% deja de formar parte del menú base. Se mantiene en Alimentos y como opción de sustitución.

- V9.10.2: crema de cacahuete 100% añadida como opción (no forma parte del menú base). Valores genéricos editables: 600 kcal, P 26 g, HC 12 g, G 50 g / 100 g.
- V9.10.4: revisión completa de raciones del menú base. Se eliminan cantidades artificiales (31.25 g, 22.8 g, 17.5 g, etc.) y se redondean a raciones prácticas, compensando pequeños cambios para conservar el planteamiento energético. Quark y crema de cacahuete siguen siendo opcionales, no alimentos fijos del menú.

V9.10.4: alimentos personalizados priorizados en macros; sugerencia de cantidad al añadir alimento; cacahuete en polvo Mercadona exacto.

V9.10.5: añade Guisantes (81 kcal, 5.4 P, 14.5 HC, 0.4 G por 100 g) como verdura rica en hidratos. Al sustituir verdura normal por guisantes, la cantidad se calcula por equivalencia energética en lugar de 1:1; también funciona la equivalencia inversa.

V9.10.6: incorpora verduras al conversor de equivalencias (brócoli, judías verdes, coliflor, calabacín, berenjena, espárragos, champiñones, pimiento, tomate, pepino, zanahoria, espinacas, cebolla, lechuga y ensalada). Entre verduras normales mantiene una ración práctica 1:1; los guisantes se ajustan por calorías por su mayor aporte de hidratos.

V9.10.7: añade una sección visible y específica 'Equivalencias de verduras' dentro de Báscula, con brócoli, judías verdes, coliflor, calabacín, berenjena, espárragos, champiñones, pimiento, tomate, pepino, zanahoria, espinacas, cebolla, lechuga, ensalada y guisantes. Verduras normales 1:1; guisantes ajustados por calorías.

- V9.10.8: coles de Bruselas congeladas incorporadas a Alimentos, Cambiar alimento y equivalencias de verduras de Bascula. Etiqueta por 100 g: 42 kcal, P 3.1 g, HC 4.8 g, grasas <0.5 g (estimacion interna 0.49 g). Pesaje congelado antes de cocinar.

V9.14.0: Base V9.10.8 con seleccion libre desde Hoy; Quark Milsani bajo en grasas (Aldi) incorporado de serie (por 100 g: 70 kcal, 12 g proteina, 3.9 g HC, 0.9 g grasa); eliminado acceso a Training. Conserva datos locales existentes.

V9.15.0: La barra superior muestra el plan diario actualizado, que reacciona a omitir/restaurar/sustituir/añadir alimentos incluso antes de marcar la comida como consumida. El panel 'Consumido' sigue contabilizando solo comidas realizadas. VitOBest Milk Protein Isolate 90 Chocolate de serie (por 100 g: 373.3 kcal, P 85, HC 3.33, G 2), y el alimento genérico 'proteína en polvo' usa los mismos valores. Datos nutricionales comunicados previamente por el usuario, pendientes de cotejo con etiqueta actual.
